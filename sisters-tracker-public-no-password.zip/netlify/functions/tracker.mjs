import { getStore } from "@netlify/blobs";
import crypto from "node:crypto";
const STORE = "sister-follow-up-records";
const KEYS = ["initial", "meet1", "meet2", "meet3"];
const store = () => getStore(STORE);
const response = (statusCode, data, headers = {}) => ({ statusCode, headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", "Access-Control-Allow-Origin": "*", ...headers }, body: JSON.stringify(data) });
function cleanStage(s = {}) { return { completed: s.completed === true, followedBy: String(s.followedBy || "").trim().slice(0, 120), comment: String(s.comment || "").trim().slice(0, 600) }; }
function clean(d = {}, old = {}) { const stages = {}; for (const k of KEYS) stages[k] = cleanStage(d.stages?.[k] || old.stages?.[k] || {}); return { id: old.id || d.id || crypto.randomUUID(), name: String(d.name || "").trim().slice(0, 120), phone: String(d.phone || "").trim().slice(0, 40), gender: ["Male", "Female"].includes(String(d.gender || old.gender || "").trim()) ? String(d.gender || old.gender).trim() : "", entryDate: String(d.entryDate || new Date().toISOString().slice(0, 10)), notes: String(d.notes || old.notes || "").trim().slice(0, 600), stages, createdAt: old.createdAt || new Date().toISOString(), updatedAt: new Date().toISOString() }; }
function valid(r) { if (!r.name || !r.phone || !/^\d{4}-\d{2}-\d{2}$/.test(r.entryDate)) return false; const d = new Date(r.entryDate + "T00:00:00Z"); return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === r.entryDate; }
async function all() { const s = store(); const keys = []; for await (const page of s.list({ prefix: "record:", paginate: true })) for (const b of page.blobs || []) keys.push(b.key); const out = []; for (const k of keys) { const r = await s.get(k, { type: "json" }); if (r) out.push(r); } return out.sort((a, b) => a.name.localeCompare(b.name)); }
export async function handler(event) {
 const method = event.httpMethod || "GET";
 const path = (event.path || "").replace(/^.*\/\.netlify\/functions\/tracker/, "").replace(/\/+$/, "");
 if (method === "OPTIONS") return response(204, {});
 let d = {}; if (event.body) { try { d = JSON.parse(event.body); } catch { return response(400, { error: "Invalid request." }); } }
 try {
  if (path === "/request" && method === "POST") {
   if (d.website) return response(200, { ok: true });
   const r = clean({ name: d.name, phone: d.phone, gender: d.gender, notes: d.notes, entryDate: new Date().toISOString().slice(0, 10) });
   if (!["Male", "Female"].includes(r.gender)) return response(400, { error: "Please select Male or Female for gender." });
   if (!r.name || !r.phone || !valid(r)) return response(400, { error: "Please provide name and phone number." });
   r.source = "public-request"; await store().setJSON(`record:${r.id}`, r); return response(201, { ok: true, record: r });
  }
  if (!path && method === "GET") return response(200, { records: await all() });
  if (!path && method === "POST") { const r = clean(d); if (!valid(r)) return response(400, { error: "Please provide a name, phone number and valid date." }); await store().setJSON(`record:${r.id}`, r); return response(201, { record: r }); }
  const m = path.match(/^\/([^/]+)$/);
  if (m && method === "PUT") { const id = decodeURIComponent(m[1]); const old = await store().get(`record:${id}`, { type: "json" }); if (!old) return response(404, { error: "Record not found." }); const r = clean(d, old); if (!valid(r)) return response(400, { error: "Please provide a name, phone number and valid date." }); await store().setJSON(`record:${id}`, r); return response(200, { record: r }); }
  if (m && method === "DELETE") { const id = decodeURIComponent(m[1]); const old = await store().get(`record:${id}`, { type: "json" }); if (!old) return response(404, { error: "Record not found." }); await store().delete(`record:${id}`); return response(200, { ok: true }); }
  return response(404, { error: "Not found." });
 } catch (e) { console.error("Tracker function error", e); return response(500, { error: "Tracker service error. Check Netlify function logs." }); }
}
