SISTERS FOLLOW-UP TRACKER — PUBLIC VERSION

This version removes team login. Anyone who has the website link can view all records and add, edit, or delete records. Names and phone numbers are therefore publicly accessible. Use only if this is acceptable; do not put sensitive or confidential information in it.

Important: Netlify manual file upload does not build/deploy Netlify Functions reliably. Deploy this project using Netlify CLI or connect this project repository to Netlify so it builds the function. Uploading the ZIP itself as a single file will not deploy the app.

Files must remain at project root: index.html, netlify.toml, package.json, netlify/functions/tracker.mjs. The function uses Netlify Blobs for persistent records. No username/password/session environment variables are required.
